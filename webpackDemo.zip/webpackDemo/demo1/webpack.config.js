const path = require('path')
function resolve (dir) {
  return path.join(__dirname, dir)
}
module.exports = [
  {
    // 单入口
    entry: resolve('src/main.js'),
    output: {
      path: __dirname + '/dist',
      filename: 'bundle.js'
    }
  },
  {
    // 多入口
    entry: {
      pageOne: resolve('src/1/index.js'),
      pageTwo: resolve('src/2/index.js')
    },
    output: {
      path: __dirname + '/dist',
      filename: '[name].js'
    }
  }
]