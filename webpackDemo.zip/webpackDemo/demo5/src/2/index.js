const a = '12345'
console.log(2)