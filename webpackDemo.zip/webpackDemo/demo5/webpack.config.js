const path = require('path')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
// 压缩
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  entry: resolve('src/main.js'),
  output: {
    path: resolve('/dist'),
    filename: 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.scss$/,
        use:[
          {
            loader: MiniCssExtractPlugin.loader,
            options: {
              // hmr: process.env.NODE_ENV === 'development',
            }
          },
          'css-loader', 'postcss-loader', 'sass-loader'
        ]
      },
      {
        test: /\.js$/,
        use: 'babel-loader',
        exclude: /node_modules/
      },
      {
        test:/\.(png|jpe?g|gif|svg)(\?.*)?$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[hash:7].[ext]',
              outputPath: 'images/',
              publicPath: '../images/'
            }
          }
        ]
      },
      {
        test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'media/[name].[hash:7].[ext]',
              outputPath: 'media/',
              publicPath: '../media/'
            }
          }
        ]
      },
      {
        test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              limit: 10000,
              name: 'fonts/[name].[hash:7].[ext]',
              outputPath: 'fonts/',
              publicPath: '../fonts/'
            }
          }
        ]
      }
    ]
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: './css/[name].css',
      chunkFilename: '[id].[hash].css'
    }),
    new OptimizeCSSAssetsPlugin({
      // 正则表达式，用于匹配需要优化或者压缩的资源名。默认值是/.css$/g
      assetNameRegExp: /\.css$/g,
      // 用于压缩和优化CSS的处理器，默认是cssnano.
      cssProcessor: require('cssnano'),
      // 传递给cssProcessor的插件选项，默认为{}
      cssProcessorPluginOptions: {
        preset: ['default', { discardComments: { removeAll: true } }],
      },
      // 表示插件能够在console中打印信息，默认值是true
      canPrint: true
    })
  ]
  // devServer: {
  //   // 当使用内联模式(inline mode)时，在开发工具(DevTools)的控制台(console)将显示消息，如：在重新加载之前，
  //   // 在一个错误之前，或者模块热替换(Hot Module Replacement)启用时。这可能显得很繁琐。
  //   clientLogLevel: 'warning',
  //   // 当使用 HTML5 History API 时，任意的 404 响应都可能需要被替代为 index.html。设置 true
  //   historyApiFallback: true,
  //   // 启用 webpack 的模块热替换特性
  //   hot: true,
  //   // 一切服务都启用 gzip 压缩
  //   compress: true,
  //   // 指定使用一个 host。默认是 localhost。如果你希望服务器外部可访问 0.0.0.0
  //   host: '0.0.0.0',
  //   // 指定要监听请求的端口号
  //   port: '8989',
  //   // 启用打开后，开发服务器将打开浏览器
  //   open: true,
  //   // 代理
  //   proxy: {}
  // },
  // cheap-module-eval-source-map - 类似 cheap-eval-source-map，并且，
  // 在这种情况下，源自 loader 的 source map 会得到更好的处理结果。
  // 然而，loader source map 会被简化为每行一个映射(mapping)。
  // devtool: 'cheap-module-eval-source-map'
}