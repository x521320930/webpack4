const a = '12345'
((w) => {
  console.log(w)
})(window)
console.log(2)